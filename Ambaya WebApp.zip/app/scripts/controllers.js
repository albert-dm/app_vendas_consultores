//'use strict';

//TODO: Tratar a geração de nome de usuário para evitar espaços e nomes iguais

angular.module('ambaya')
	
		//Implementação Ambaya
		.controller('BaseController',['loginService', '$scope', '$state', '$localStorage', function(loginService, $scope, $state, $localStorage){
			$(".button-collapse").sideNav({
                closeOnClick: true, // Closes side-nav on <a> clicks, useful for Angular/Meteor
                draggable: true // Choose whether you can drag to open on touch screens
            });
            $scope.usuario = {username: "", password: ""};
            var rotas = {
                    "Consultor": [
                        {nome:"Início", icone:"home"}
                    ],
                    "Supervisor": [
                        {nome:"Início", icone:"home"},
                        {nome:"Consultores", icone:"people"},
                        {nome:"Estoque", icone:"business_center"},
                        {nome:"Encomendas", icone:"loop"},
                        //{nome:"Acertos", icone:"done_all"},
                    ],
                    "Controladoria": [
                        {nome:"Início", icone:"home"},
                        {nome:"Consultores", icone:"people"},
                        {nome:"Supervisores", icone:"people"},
                        //{nome:"Relatórios", icone:"assignment"}
                    ],
                    "Estoque": [
                        {nome:"Início", icone:"home"},
                        {nome:"Encomendas", icone:"loop"},
                    ]
            };
            $scope.login = function(){
                loginService.login($scope.usuario).then(
                    function(response) {
                        //console.log(response);
                        $localStorage.usuario = response.data.user;
                        $localStorage.token = response.data.token;
                        $localStorage.logado = true;
                        $scope.usuario = response.data.user;
                        $scope.rotas= rotas[$scope.usuario.tipo];
                        $scope.tipo = $scope.usuario.tipo;
                        $scope.logado = true;
                        $state.reload();
                    },
                    function(response) {
                        Materialize.toast("Login inválido", 3000);
                    }
                );
                // $scope.logado = loginService.check();
                // if($scope.logado){
                //     $scope.usuario = loginService.getUser();;
                //     $state.go("Início");
                //     $scope.rotas= rotas[$scope.usuario.tipo];
                //     $scope.tipo = $scope.usuario.tipo;
                //     $scope.logado = true;
                // } else {
                //     UIkit.notify({
                //         message : "Login Inválido!",
                //         status  : "danger",
                //         timeout : 5000,
                //         pos     : 'bottom-center'
                //     });
                // }
            };
            $scope.sair = function(){
                loginService.logout();
                $scope.logado = false;
                $scope.tipo = "Login";
                if($state.is('Início'))
                    $state.reload();
                else
                    $state.go('Início');
                
            };
            
            $scope.logado = loginService.check();
            if ($scope.logado) {
                $scope.usuario = loginService.getUser();
                $scope.rotas= rotas[$scope.usuario.tipo];
                $scope.tipo = $scope.usuario.tipo;
            }else{
                $scope.tipo = "Login";
                //é necessário redirecionar para o início aqui.
            }           
            $scope.$state = $state;

            //funcoes globais
            $scope.faltamDias = function(diaFuturo) {
                diaFuturo = new Date(diaFuturo);
                return Math.floor((diaFuturo - Date.now())/(24*60*60*1000));
            }; 
            $scope.deletaElemento = function(vetor, index){
                vetor.splice(index, 1);
            }
            $scope.processaPecas = function(estoque){
                var pecas = {
                    "aneis":[],
                    "brincosP": [],
                    "brincosG": [],
                    "cordoesF": [],
                    "cordoesM": [],
                    "pingentes": [],
                    "pulseirasF": [],
                    "pulseirasM": [],
                    "tornozeleiras": [],
                    "escapularios": []
                }
                console.log(estoque);
                for(i=0; i<estoque.length; i++){
                    console.log(estoque[i]);
                    tipo = estoque[i].substr(0,2);
                    //mes = peca.splice(2,2);
                    //ano = peca.splice(4,2);
                    valor = estoque[i].substr(6,2);
                    switch(tipo){
                        case "AN":
                            tipo = "aneis";
                            break;
                        case "BP":
                            tipo = "brincosP";
                            break;
                        case "BG":
                            tipo = "brincosG";
                            break;
                        case "CF":
                            tipo = "cordoesF";
                            break;
                        case "CM":
                            tipo = "cordoesM";
                            break;
                        case "PI":
                            tipo = "pingentes";
                            break;
                        case "PF":
                            tipo = "pulseirasF";
                            break;
                        case "PM":
                            tipo = "pulseirasM";
                            break;
                        case "TO":
                            tipo = "tornozeleiras";
                            break;
                        case "ES":
                            tipo = "escapularios";
                            break;
                    }
                    if(pecas[tipo].length!=0){
                        $.grep(pecas[tipo], function(e){                         
                            if(e.val==valor){
                                    e.tot++;
                                    existe=true;
                                } else{
                                    console.log("novo");
                                    existe=false;
                                }
                            });
                    } else
                        existe = false;
                    console.log(existe);
                    if(!existe){
                        console.log("inserido");
                        pecas[tipo].push({"val": valor, "tot": 1});
                    }                        
                }
                console.log(pecas);
                return pecas;
            }
                
		}])
        //Controladoria
        .controller('ControladoriaInicioController',[ '$scope', 'controladoriaService', function($scope, controladoriaService){
            $('.tooltipped').tooltip({delay: 50});
            controladoriaService.consultores().then(
                    function(response) {
                        $scope.consultores=response.data;
                    },
                    function(response) {
                            /*UIkit.notify({
                            message : "Falha ao carregar consultores!",
                            status  : "danger",
                            timeout : 5000,
                            pos     : 'bottom-center'
                        });*/
                    }
            );
            controladoriaService.supervisores().then(
                    function(response) {
                        $scope.supervisores=response.data;
                    },
                    function(response) {
                            /*UIkit.notify({
                            message : "Falha ao carregar consultores!",
                            status  : "danger",
                            timeout : 5000,
                            pos     : 'bottom-center'
                        });*/
                    }
            );
		}])
        .controller('ConsultoresControladoriaController',[ '$scope', 'consultoresService', function($scope, consultoresService){
            $('.tooltipped').tooltip({delay: 50});
            consultoresService.todos().then(
                    function(response) {
                        $scope.consultores = response.data;
                        $scope.total = $scope.consultores.length; 
                    },
                    function(response) {
                            Materialize.toast("Falha ao carregar Consultores", 5000);
                    }
            );
		}])
        .controller('SupervisoresController',[ '$scope', 'supervisoresService', 'userService', function($scope, supervisoresService, userService){
            //mascaras para formulario
            $('.cep').mask('00000-000');
            $('.cpf').mask('000.000.000-00', {reverse: true});

            var telefoneFuncao = function (val) {
                return val.replace(/\D/g, '').length === 11 ? '(00) 00000-0000' : '(00) 0000-00009';
                },
                telOptions = {
                onKeyPress: function(val, e, field, options) {
                    field.mask(telefoneFuncao.apply({}, arguments), options);
                    }
            };

            $('.telefone').mask(telefoneFuncao, telOptions);
            //fim das mascaras

            //ui config
            $('.tooltipped').tooltip({delay: 50});
            $('select').material_select();
            $('.datepicker').pickadate({
                selectMonths: true, // Creates a dropdown to control month
                selectYears: 100 // Creates a dropdown of 15 years to control year
            });
            //fim ui config

            carregaSupervisores = function(){
                supervisoresService.todos().then(
                    function(response) {
                        $scope.supervisores = response.data;
                        $scope.total = $scope.supervisores.length; 
                    },
                    function(response) {
                            Materialize.toast("Falha ao carregar supervisores!", 5000);
                    }
                );
            };
            carregaSupervisores();

            //formulario de adição
            $scope.form = {
                "nome":"",
                "sobrenome":"",
                "tipo":"Supervisor",
                "status": "Aprovado",
                "porcentagem": 30,
                "estoque": [],
                "vendido":[],
                "investidor": false,
                "totalVendido": 0,
                "proxAcerto": Date.now()+45*24*60*60*1000
            };
            $('#adicionar').modal();
            $scope.add = function(){
                $('#adicionar').modal('open');
            }
            $scope.novo = function(){
                var acerto = Date.now()+45*24*60*60*1000;
                $scope.form.username = $scope.form.nome.toLowerCase();
                $scope.form.password = $scope.form.username;
                userService.novo($scope.form).then(
                    function(response) {
                        //console.log(response);
                        $('#adicionar').modal('close');
                        $scope.form = {
                            "nome":"",
                            "sobrenome":"",
                            "tipo":"Supervisor",
                            "status": "Aprovado",
                            "porcentagem": 30,
                            "estoque": [],
                            "vendido":[],
                            "investidor": false,
                            "totalVendido": 0,
                            "proxAcerto": Date.now()+45*24*60*60*1000
                        };
                        Materialize.toast("Supervisor adicionado com sucesso!", 5000);
                        carregaSupervisores();
                    },
                    function(response) {
                        Materialize.toast(response.err.message, 5000);
                    }
                );
                
            };
		}])
        .controller('SupervisorController',[ '$scope', 'supervisoresService', 'userService', 'consultoresService', '$stateParams', function($scope, supervisoresService, userService, consultoresService, $stateParams){
            //mascaras para formulario
            $('.cep').mask('00000-000');
            $('.cpf').mask('000.000.000-00', {reverse: true});

            var telefoneFuncao = function (val) {
                return val.replace(/\D/g, '').length === 11 ? '(00) 00000-0000' : '(00) 0000-00009';
                },
                telOptions = {
                onKeyPress: function(val, e, field, options) {
                    field.mask(telefoneFuncao.apply({}, arguments), options);
                    }
            };

            $('.telefone').mask(telefoneFuncao, telOptions);
            //fim das mascaras

            //ui config
            $('.tooltipped').tooltip({delay: 50});
            $('select').material_select();
            $('.datepicker').pickadate({
                selectMonths: true, // Creates a dropdown to control month
                selectYears: 100 // Creates a dropdown of 15 years to control year
            });
            //fim ui config

            var id =  $stateParams.supervisorId;
            userService.carregaUm(id).then(
                    function(response) {
                        $scope.supervisor = response.data;
                    },
                    function(response) {
                        Materialize.toast("Falha ao carregar dados", 5000);
                    }
            );
            var carregaConsultores = function(){
                consultoresService.porSupervisor(id).then(
                    function(response) {
                        $scope.consultores = response.data;
                    },
                    function(response) {
                        Materialize.toast("Falha ao carregar dados", 5000);
                    }
                );
            };
            carregaConsultores();   

            $scope.form = {
                "nome":"",
                "sobrenome":"",
                "tipo":"Consultor",
                "status": "Aprovado",
                "supervisor": id,
                "porcentagem": 10,
                "estoque": [],
                "vendido": [],
                "totalVendido": 0,
                "proxAcerto": Date.now()+45*24*60*60*1000
            };
            $('#adicionar').modal();
            $('#excluir').modal();
            $scope.add = function(){
                $('#adicionar').modal('open');
            }
            $scope.del = function(){
                $('#excluir').modal('open');
            }
            $scope.novo = function(){
                console.log($scope.form);
                $scope.form.username = $scope.form.nome.toLowerCase();
                $scope.form.password = $scope.form.username;
                userService.novo($scope.form).then(
                    function(response) {
                        //console.log(response);
                        $('#adicionar').modal('close');
                        $scope.form = {
                            "nome":"",
                            "sobrenome":"",
                            "tipo":"Consultor",
                            "status": "Aprovado",
                            "supervisor": id,
                            "porcentagem": 10,
                            "estoque": [],
                            "vendido": [],
                            "totalVendido": 0,
                            "proxAcerto": Date.now()+45*24*60*60*1000
                        };
                        carregaConsultores();
                        Materialize.toast("Consultor adicionado com sucesso!", 5000);
                    },
                    function(response) {
                        Materialize.toast("response.err.message", 5000);
                    }
                );                
            };         
           $scope.excluir = function(){
                userService.deletaUm($scope.supervisor._id).then(
                    function(response) {
                        Materialize.toast("Excluido com sucesso!", 5000);
                        window.history.back();
                    },
                    function(response) {
                        Materialize.toast("Falha ao excluir", 5000);
                    }
                );                
           }
		}])
        .controller('ConsultorController',[ '$scope', 'userService', 'consultoresService', '$stateParams', function($scope, userService, consultoresService, $stateParams){
            $('.tooltipped').tooltip({delay: 50});
            var id =  $stateParams.consultorId;
            userService.carregaUm(id).then(
                    function(response) {
                        $scope.consultor = response.data;
                    },
                    function(response) {
                            Materialize.toast("Falha ao carregar dados!", 3000);
                    }
            );

            $('#excluir').modal();
            $scope.del = function(){
                $('#excluir').modal('open');
            }

            $scope.excluir = function(){
                userService.deletaUm($scope.consultor._id).then(
                    function(response) {
                        Materialize.toast("Excluído com sucesso", 5000);
                        window.history.back();
                    },
                    function(response) {
                        Materialize.toast("Falha ao excluir", 5000);
                    }
                );                
            };
            $scope.aprovar = function(){
                 consultoresService.aprovar(id).then(
                    function(response) {
                        $scope.consultor.status = "Aprovado";
                    },
                    function(response) {
                        Materialize.toast("Falha ao atualizar", 5000);
                    }
                );
            };
            $scope.desaprovar = function(){
                 consultoresService.desaprovar(id).then(
                    function(response) {
                        $scope.consultor.status = "Inativo";
                    },
                    function(response) {
                        Materialize.toast("Falha ao atualizar", 5000);
                    }
                );
            };
		}])
        //Supervisor
        .controller('SupervisorInicioController',[ '$scope', 'supervisoresService', 'consultoresService', function($scope, supervisoresService, consultoresService){
            $('.tooltipped').tooltip({delay: 50});
            supervisoresService.carregaUm($scope.usuario._id).then(
                    function(response) {
                        $scope.dados = response.data;
                         consultoresService.porSupervisor($scope.usuario._id).then(
                                function(response) {
                                    var resposta = response.data;
                                    var consultores = {
                                        total:0,
                                        totalVendido: 0,
                                        valorVendido: 0,
                                        totalPecas: 0
                                    };
                                    for (var i=0; i<resposta.length; i++){
                                        consultores.totalVendido += resposta[i].pecasVendidas.length;
                                        consultores.valorVendido += resposta[i].vendido;
                                        consultores.totalPecas += resposta[i].pecas.length;
                                        consultores.lucro = resposta[i].vendido*(resposta[i].porcentagem)/100;
                                    }
                                    consultores.total = resposta.length;
                                    $scope.dados.consultores = consultores;
                                    $scope.dados.acerto = consultores.valorVendido - consultores.lucro - consultores.valorVendido*($scope.dados.porcentagem)/100;                 
                                },
                                function(response) {
                                        /*UIkit.notify({
                                        message : "Falha ao carregar consultores!",
                                        status  : "danger",
                                        timeout : 5000,
                                        pos     : 'bottom-center'
                                    });*/
                                }
                        );
                    },
                    function(response) {
                            /*UIkit.notify({
                            message : "Falha ao carregar dados!",
                            status  : "danger",
                            timeout : 5000,
                            pos     : 'bottom-center'
                        });*/
                    }
            );
		}])
        .controller('ConsultoresSupervisorController',[ '$scope', 'consultoresService', 'userService', function($scope, consultoresService, userService){
           //mascaras para formulario
            $('.cep').mask('00000-000');
            $('.cpf').mask('000.000.000-00', {reverse: true});

            var telefoneFuncao = function (val) {
                return val.replace(/\D/g, '').length === 11 ? '(00) 00000-0000' : '(00) 0000-00009';
                },
                telOptions = {
                onKeyPress: function(val, e, field, options) {
                    field.mask(telefoneFuncao.apply({}, arguments), options);
                    }
            };

            $('.telefone').mask(telefoneFuncao, telOptions);
            //fim das mascaras

            //ui config
            $('.tooltipped').tooltip({delay: 50});
            $('select').material_select();
            $('.datepicker').pickadate({
                selectMonths: true, // Creates a dropdown to control month
                selectYears: 100 // Creates a dropdown of 15 years to control year
            });
            //fim ui config
           carregaConsultores = function(){
               consultoresService.porSupervisor($scope.usuario._id).then(
                    function(response) {
                        $scope.consultores = response.data;
                        var consultores = {
                            total:0,
                            totalVendido: 0,
                            valorVendido: 0,
                            totalPecas: 0
                        };
                        for (var i=0; i<$scope.consultores.length; i++){
                            consultores.totalVendido += $scope.consultores[i].vendido.length;
                            consultores.valorVendido += $scope.consultores[i].totalVendido;
                            consultores.totalPecas += $scope.consultores[i].estoque.length;
                        }
                        $scope.valorVendido = consultores.valorVendido;
                        $scope.totalPecas = consultores.totalPecas + consultores.totalVendido; //considerando a soma entre pecas vendidas e guardadas por cada consultor
                        $scope.total = $scope.consultores.length;
                    },
                    function(response) {
                         Materialize.toast("Falha ao carregar consultores", 5000);
                    }
                );
           }
           carregaConsultores();

            $scope.form = {
                "nome":"",
                "sobrenome":"",
                "tipo":"Consultor",
                "supervisor": $scope.usuario._id,
                "porcentagem": 10,
                "estoque": [],
                "vendido": [],
                "totalVendido": 0,
                "proxAcerto": Date.now()+45*24*60*60*1000
            };
            $('#adicionar').modal();
            $scope.add = function(){
                $('#adicionar').modal('open');
            }
            $scope.novo = function(){
                console.log($scope.form);
                $scope.form.username = $scope.form.nome.toLowerCase();
                $scope.form.password = $scope.form.username;
                userService.novo($scope.form).then(
                    function(response) {
                        //console.log(response);
                        $('#adicionar').modal('close');
                        $scope.form = {
                            "nome":"",
                            "sobrenome":"",
                            "tipo":"Consultor",
                            "supervisor": $scope.usuario._id,
                            "porcentagem": 10,
                            "estoque": [],
                            "vendido": [],
                            "totalVendido": 0,
                            "proxAcerto": Date.now()+45*24*60*60*1000
                        };
                        Materialize.toast("Consultor adicionado com sucesso!", 5000);
                        carregaConsultores();
                    },
                    function(response) {
                        Materialize.toast(response.err.message, 5000);
                    }
                );                
            };         
		}])
        .controller('EstoqueSupervisorController',[ '$scope', 'consultoresService', function($scope, consultoresService){
           $('.tooltipped').tooltip({delay: 50});
           consultoresService.porSupervisor($scope.usuario._id).then(
                    function(response) {
                        $scope.consultores = response.data;
                        var consultores = {
                            total:0,
                            totalVendido: 0,
                            valorVendido: 0,
                            totalPecas: 0
                        };
                        for (var i=0; i<$scope.consultores.length; i++){
                            consultores.totalVendido += $scope.consultores[i].pecasVendidas.length;
                            consultores.valorVendido += $scope.consultores[i].vendido;
                            consultores.totalPecas += $scope.consultores[i].pecas.length;
                        }
                        $scope.valorVendido = consultores.valorVendido;
                        $scope.totalPecas = consultores.totalPecas + consultores.totalVendido; //considerando a soma entre pecas vendidas e guardadas por cada consultor
                        $scope.total = $scope.consultores.length;
                    },
                    function(response) {
                            /*UIkit.notify({
                            message : "Falha ao carregar consultores!",
                            status  : "danger",
                            timeout : 5000,
                            pos     : 'bottom-center'
                        });*/
                    }
            );
        }])
        //Consultor
        .controller('ConsultorInicioController',[ '$scope', 'consultoresService', 'userService', function($scope, consultoresService, userService){
            $('.tooltipped').tooltip({delay: 50});
            $scope.codigo = "";
            consultoresService.carregaUm($scope.usuario._id).then(
                    function(response) {
                        $scope.dados = response.data;
                        console.log($scope.dados);
                        userService.carregaUm($scope.dados.supervisor).then(
                                function(response) {
                                    $scope.supervisor = response.data;
                                },
                                function(response) {
                                        Materialize.toast("Falha ao carregar dados do supervisor!", 3000, 'white');
                                }
                        );
                    },
                    function(response) {
                            Materialize.toast("Falha ao carregar dados!", 3000);
                    }
            );
			$scope.vender = function(){
                Materialize.toast($scope.codigo + " vendido!", 3000, 'white textoPreto');
                $scope.codigo = "";
            };
		}])
        //Estoque
        .controller('EstoqueInicioController',[ '$scope', 'estoqueService', function($scope, estoqueService){
            $('.tooltipped').tooltip({delay: 50});
            $('#entrada').modal();
            var estoque = [];
            $scope.adicionando = [];
            $scope.pecas = {
                    "aneis":[],
                    "brincosP": [],
                    "brincosG": [],
                    "cordoesF": [],
                    "cordoesM": [],
                    "pingentes": [],
                    "pulseirasF": [],
                    "pulseirasM": [],
                    "tornozeleiras": [],
                    "escapularios": []
                }
            $scope.codigo = "";
            $scope.abrir = function(){
                $('#entrada').modal('open');
                $('#codigo').focus();
            }
            $scope.entrada = function(){
                //verificar se código está correto
                //adicionar possibilidade de desfazer ação
                //Materialize.toast($scope.codigo + "OK", 5000);
                $scope.adicionando.push($scope.codigo);
                $scope.codigo = ""
            }
            $scope.concluir = function(){
                //deve existir possibilidade de cancelar última adição
                estoque = estoque.concat($scope.adicionando);
                //console.log(estoque);
                $scope.pecas = $scope.processaPecas(estoque);
                $scope.adicionando = [];
                $('#entrada').modal('close');
            }
		}])




        /////////////////////////////////////////////////////////////
		.controller('UsuariosController',[ '$scope', function($scope){
			$('.tooltipped').tooltip({delay: 50});
            $scope.titulo = "Usuários";
		}])
        .controller('InicioController',[ '$scope', function($scope){
			$('.tooltipped').tooltip({delay: 50});
            $scope.titulo = "Início";
		}])	

        
;
	