'use strict';

angular.module('ambaya')
        .service('userService', function($http){
            this.novo = function(usuario){
                return $http.post("/users/register", usuario);
            };
            this.carregaUm = function(id){
                return $http.get("/users/"+id);
            };
            this.deletaUm = function(id){
                return $http.delete("/users/"+id);
            };
        })
        .service('loginService', function($localStorage, $http, $location) {    
                this.login = function (usuario) {
                    return $http.post("/users/login", usuario);                    
                };
                this.check = function(){                    
                    return $localStorage.logado;             
                };
                this.getUser = function(){
                    if ($localStorage.logado)
                    return $localStorage.usuario;   
                    else return false;   
                };
                this.logout = function(){
                    $localStorage.logado = false;
                    return;
                };
        })
        .service('estoqueService', function() {
            this.dados = function(){
                var dado = {
                    "pedidos":12,
                    "acertos": [{"info":"Supervisor", "desc": 37}, {"info":"Supervisor", "desc": 37}, {"info":"Supervisor", "desc": 37}, {"info":"Supervisor", "desc": 37}, {"info":"Supervisor", "desc": 37}, {"info":"Supervisor", "desc": 37}, {"info":"Supervisor", "desc": 37}],
                    "pecas": [{"info":"Anel", "desc": 5}, {"info":"Pulseira", "desc": 20},{"info":"Cordão", "desc": 3}]
                };
                return dado;
            };
        })
        .service('controladoriaService', function($http) {
            this.consultores = function(){
                return $http.get("users/consultores/num");
            };
            this.supervisores = function(){
                return $http.get("users/supervisores/num");
            };
        })
        .service('consultoresService', function($http) {
            this.todos = function(){
                return $http.get("users/consultores/");
            };
            this.porSupervisor = function(id){
                return $http.get("users/consultores/"+id);
            };
            this.aprovar = function(id){
                return $http.post("/users/atualizar/",
                {
                    _id: id,
                    update: {status: 'Aprovado'}
                }
                );
            };
            this.desaprovar = function(id){
                return $http.post("/users/atualizar/",
                {
                    _id: id,
                    update: {status: 'Inativo'}
                }
                );
            }
        })
        .service('supervisoresService', function($http) {
            this.todos = function(){
                return $http.get("users/supervisores/");
            };
        })
;
